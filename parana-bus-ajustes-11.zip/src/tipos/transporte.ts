export interface Coordenadas { latitud: number; longitud: number; }
export type Sentido = "ida" | "vuelta";
export type TipoDeDia = "habil" | "sabado" | "domingo" | "feriado";
export type Gravedad = "informativo" | "desvio" | "suspension";
export type MotivoDemora = "no_paso" | "paso_lleno" | "demorado" | "unidad_rota" | "calle_cortada";
export type Tema = "claro" | "oscuro" | "sistema";
export interface Recorrido { sentido: Sentido; destino: string; trazado: Coordenadas[]; paradaIds: string[]; }
export interface Linea { id: string; numero: string; nombre: string; color: string; empresa: string; recorridos: Recorrido[]; activa: boolean; }
export interface Parada { id: string; nombre: string; coordenadas: Coordenadas; lineaIds: string[]; sentido: Sentido; refugio: boolean; codigoQr: string | null; }
export interface Horario { id: string; lineaId: string; paradaId: string; sentido: Sentido; tipoDeDia: TipoDeDia; hora: string; }
export interface Aviso { id: string; titulo: string; detalle: string; lineaIds: string[]; desde: string; hasta: string | null; gravedad: Gravedad; trazadoAlternativo: Coordenadas[] | null; videoUrl: string | null; }
export interface ReporteDeDemora { id: string; lineaId: string; paradaId: string; usuarioId: string; motivo: MotivoDemora; comentario: string | null; fotoUri: string | null; confirmaciones: number; fechaHora: string; sincronizado: boolean; }
export interface Usuario { id: string; nombre: string; email: string; lineasFavoritas: string[]; paradasFavoritas: string[]; avisosActivos: boolean; tema: Tema; }

export interface Feriado { fecha: string; nombre: string; }
